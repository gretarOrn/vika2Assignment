#ifndef UNABLETOREADFILEEXCEPTION_H
#define UNABLETOREADFILEEXCEPTION_H


class UnableToReadFileException
{
    public:
        UnableToReadFileException();
        virtual ~UnableToReadFileException();

    protected:

    private:
};

#endif // UNABLETOREADFILEEXCEPTION_H
