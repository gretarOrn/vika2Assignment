#ifndef PIZZASIZESERVICE_H
#define PIZZASIZESERVICE_H


class PizzaSizeService
{
    public:
        PizzaSizeService();
        virtual ~PizzaSizeService();

    protected:

    private:
};

#endif // PIZZASIZESERVICE_H
