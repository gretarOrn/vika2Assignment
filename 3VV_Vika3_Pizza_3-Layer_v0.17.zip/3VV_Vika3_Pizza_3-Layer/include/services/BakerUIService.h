#ifndef BAKERUISERVICE_H
#define BAKERUISERVICE_H


class BakerUIService
{
    public:
        BakerUIService();
        virtual ~BakerUIService();

    protected:

    private:
};

#endif // BAKERUISERVICE_H
