#ifndef PIZZASAUCESERVICE_H
#define PIZZASAUCESERVICE_H


class PizzaSauceService
{
    public:
        PizzaSauceService();
        virtual ~PizzaSauceService();

    protected:

    private:
};

#endif // PIZZASAUCESERVICE_H
