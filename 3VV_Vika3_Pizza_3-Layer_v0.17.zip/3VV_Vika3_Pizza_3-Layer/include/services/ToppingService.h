#ifndef TOPPINGSERVICE_H
#define TOPPINGSERVICE_H


class ToppingService
{
    public:
        ToppingService();
        virtual ~ToppingService();

    protected:

    private:
};

#endif // TOPPINGSERVICE_H
