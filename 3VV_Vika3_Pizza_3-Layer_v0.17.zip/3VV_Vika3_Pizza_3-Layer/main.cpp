#include "MainUI.h"

int main()
{
    MainUI ui;
    ui.startUI();
    return 0;
}
