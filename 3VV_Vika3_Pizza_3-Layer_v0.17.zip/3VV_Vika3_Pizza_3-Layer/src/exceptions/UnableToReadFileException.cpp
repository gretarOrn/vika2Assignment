#include "UnableToReadFileException.h"

UnableToReadFileException::UnableToReadFileException()
{
    //ctor
}

UnableToReadFileException::~UnableToReadFileException()
{
    //dtor
}
