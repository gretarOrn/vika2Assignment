#include "PizzaService.h"

PizzaService::PizzaService() {
    //ctor
}

PizzaSauce PizzaService::addSauce(int sauceNR) {
    PizzaSauce pizzaSauce;
    pizzaSauce.setIdNumber(dataBase.sauceMaster[sauceNR - 1].getIdNumber());
    pizzaSauce.setName(dataBase.sauceMaster[sauceNR - 1].getName());
    pizzaSauce.setPriceCategory(dataBase.sauceMaster[sauceNR - 1].getPriceCategory());
    pizzaSauce.setActiveState(dataBase.sauceMaster[sauceNR - 1].getActiveState());
    return pizzaSauce;

}
PizzaSize PizzaService::addSize(int sizeNR) {
    PizzaSize pizzaSize;
    pizzaSize.setIdNumber(dataBase.sizeMaster[sizeNR - 1].getIdNumber());
    pizzaSize.setName(dataBase.sizeMaster[sizeNR - 1].getName());
    pizzaSize.setPriceCategory(dataBase.sizeMaster[sizeNR - 1].getPriceCategory());
    pizzaSize.setActiveState(dataBase.pizzaMaster[sizeNR - 1].getActiveState());
    return pizzaSize;

}
PizzaType PizzaService::addType(int typeNR) {
    PizzaType pizzaType;
    pizzaType.setIdNumber(dataBase.typeMaster[typeNR - 1].getIdNumber());
    pizzaType.setName(dataBase.typeMaster[typeNR - 1].getName());
    pizzaType.setPriceOffset(dataBase.typeMaster[typeNR - 1].getPriceOffset());
    pizzaType.setActiveState(dataBase.typeMaster[typeNR - 1].getActiveState());
    return pizzaType;
}

Topping* PizzaService::addTopping(int *arr, Pizza& pizza) {
    int counter = 0;
    for (int i = 0; arr[i] != 0; i++) {
        counter ++;
    }
    for (int i = 0; arr[i] != 0; i++) {
        pizza.getToppings()[i].setIdNumber(dataBase.toppingMaster[arr[i] - 1].getIdNumber());
        pizza.getToppings()[i].setName(dataBase.toppingMaster[arr[i] - 1].getName());
        pizza.getToppings()[i].setPriceCategory(dataBase.toppingMaster[arr[i] - 1].getPriceCategory());
        pizza.getToppings()[i].setActiveState(dataBase.toppingMaster[arr[i] - 1].getActiveState());
    }
    return pizza.getToppings();


}

void PizzaService::addPizzaToOrder(Pizza& pizza, const Topping& topping) {
    int counter = 0;
    while(counter < pizza.MAX_TOPPINGS_PIZZA) {
        // If a pizzas sauce has no name the pizza is created by the default constructor and is blank.
        if(pizza.getToppings()[counter].getName() == "") {
            pizza.getToppings()[counter] = topping;
            break;
        }
        counter++;
    }
    if(counter == pizza.MAX_TOPPINGS_PIZZA -1) {
        /// Throw maxToppingsPerPizzaException();
        cout << "You have reached the maximum amount of toppings on this pizza." << endl;
        cin.clear();
    }
}

double PizzaService::getPrice(Pizza pizza) {
    PriceList* priceList = dataBase.priceMaster;

    double num = 0;
    double mult = pizza.getSize().getToppingMult();
    double off = pizza.getSize().getToppingOffset();
    for (int i = 0; pizza.getToppings()[i].getName() != ""; i++) {
        num += priceList[pizza.getToppings()[i].getPriceCategory()-1].getPrice() * mult + off;
    }
    num += priceList[pizza.getSize().getPriceCategory() - 1].getPrice();
    num += pizza.getType().getPriceOffset() * mult;

    return  num;



}
/*void Pizza::addSause() {

    int lines = sauce.getLines();
    PizzaSauce* sauceMaster = sauce.readFile();

    for(int i = 0; i < lines; i++) {
        if(sauceMaster[i].getActive()) {
            cout << sauceMaster[i];
        }
    }

    int userInput;
    cin >> userInput;
    sauce.setIdNumber(sauceMaster[userInput - 1].getIdNumber());
    sauce.setName(sauceMaster[userInput - 1].getName());
    sauce.setPriceCategory(sauceMaster[userInput - 1].getPriceCategory());
}
*/
//PizzaService::addTopping(topping) {

//}
