#include "PizzaSauceService.h"

PizzaSauceService::PizzaSauceService()
{
    //ctor
}

PizzaSauceService::~PizzaSauceService()
{
    //dtor
}
