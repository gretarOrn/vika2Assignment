#include "BakerUIService.h"

BakerUIService::BakerUIService()
{
    //ctor
}

BakerUIService::~BakerUIService()
{
    //dtor
}
