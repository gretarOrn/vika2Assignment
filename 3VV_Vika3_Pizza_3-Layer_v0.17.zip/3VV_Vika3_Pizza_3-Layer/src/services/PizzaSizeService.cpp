#include "PizzaSizeService.h"

PizzaSizeService::PizzaSizeService()
{
    //ctor
}

PizzaSizeService::~PizzaSizeService()
{
    //dtor
}
