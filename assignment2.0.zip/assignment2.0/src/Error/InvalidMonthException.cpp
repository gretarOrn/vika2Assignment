#include "..\..\include\error\InvalidMonthException.h"

InvalidMonthException::InvalidMonthException()
{
    //ctor
}


