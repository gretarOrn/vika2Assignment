#include "..\..\include\error\InvalidYearException.h"

InvalidYearException::InvalidYearException()
{
    //ctor
}

