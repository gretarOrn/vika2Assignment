#include "..\..\include\error\InvalidSSNException.h"

InvalidSSNException::InvalidSSNException()
{
    //ctor
}

