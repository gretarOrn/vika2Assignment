#include "..\..\include\error\InvalidSalaryException.h"

InvalidSalaryException::InvalidSalaryException()
{
    //ctor
}

