#include <iostream>
#include "include\UI\SalaryUI.h"


using namespace std;

int main()
{
    SalaryUI salaryUI;
    salaryUI.mainMenu();
    return 0;
}
