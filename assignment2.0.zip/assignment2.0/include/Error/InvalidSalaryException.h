#ifndef INVALIDSALARYEXCEPTION_H
#define INVALIDSALARYEXCEPTION_H


class InvalidSalaryException
{
    public:
        InvalidSalaryException();
   private:
};

#endif // INVALIDSALARYEXCEPTION_H
