#ifndef INVALIDSSNEXCEPTION_H
#define INVALIDSSNEXCEPTION_H


class InvalidSSNException
{
    public:
        InvalidSSNException();
    private:
};

#endif // INVALIDSSNEXCEPTION_H
