#ifndef INVALIDMONTHEXCEPTION_H
#define INVALIDMONTHEXCEPTION_H


class InvalidMonthException
{
    public:
        InvalidMonthException();
    private:
};

#endif // INVALIDMONTHEXCEPTION_H
