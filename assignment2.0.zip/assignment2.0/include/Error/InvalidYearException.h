#ifndef INVALIDYEAREXCEPTION_H
#define INVALIDYEAREXCEPTION_H


class InvalidYearException
{
    public:
        InvalidYearException();
    private:
};

#endif // INVALIDYEAREXCEPTION_H
